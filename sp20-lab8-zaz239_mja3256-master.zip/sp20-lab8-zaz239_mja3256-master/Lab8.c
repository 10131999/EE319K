// Lab8.c
// Runs on LM4F120 or TM4C123
// Student names: Matthew Anderson, Zane Zwanenburg
// Last modification date: change this to the last modification date or look very silly
// Last Modified: 1/17/2020 

// Specifications:
// Measure distance using slide pot, sample at 10 Hz
// maximum distance can be any value from 1.5 to 2cm
// minimum distance is 0 cm
// Calculate distance in fixed point, 0.01cm
// Analog Input connected to PD2=ADC5
// displays distance on Sitronox ST7735
// PF3, PF2, PF1 are heartbeats (use them in creative ways)
// 

#include <stdint.h>

#include "ST7735.h"
#include "TExaS.h"
#include "ADC.h"
#include "print.h"
#include "../inc/tm4c123gh6pm.h"

//*****the first three main programs are for debugging *****
// main1 tests just the ADC and slide pot, use debugger to see data
// main2 adds the LCD to the ADC and slide pot, ADC data is on ST7735
// main3 adds your convert function, position data is no ST7735

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts

#define PF1       (*((volatile uint32_t *)0x40025008))
#define PF2       (*((volatile uint32_t *)0x40025010))
#define PF3       (*((volatile uint32_t *)0x40025020))
// Initialize Port F so PF1, PF2 and PF3 are heartbeats
void PortF_Init(void){
	SYSCTL_RCGCGPIO_R |= 0x20;
	while((SYSCTL_PRGPIO_R&0x01) == 0){};
	GPIO_PORTF_DIR_R |= 0x0E;
	GPIO_PORTF_DEN_R |= 0x0E;
	
}
uint32_t Data;        // 12-bit ADC
uint32_t Position;    // 32-bit fixed-point 0.001 cm
int main1(void){       // single step this program and look at Data
  TExaS_Init();       // Bus clock is 80 MHz 
  ADC_Init();         // turn on ADC, set channel to 5
  while(1){                
    Data = ADC_In();  // sample 12-bit channel 5
  }
}

uint32_t time0,time1,time2,time3;
uint32_t ADCtime,OutDectime; // in usec
int main2(void){
  TExaS_Init();   	// Bus clock is 80 MHz
  NVIC_ST_RELOAD_R = 0x00FFFFFF; // maximum reload value
  NVIC_ST_CURRENT_R = 0;      	// any write to current clears it
  NVIC_ST_CTRL_R = 5;
  ADC_Init();     	// turn on ADC, set channel to 5
  ADC0_SAC_R = 4;   // 16-point averaging, move this line into your ADC_Init()
  ST7735_InitR(INITR_REDTAB);
  while(1){       	// use SysTick 
    time0 = NVIC_ST_CURRENT_R;
    Data = ADC_In();  // sample 12-bit channel 5
    time1 = NVIC_ST_CURRENT_R;
    ST7735_SetCursor(0,0);
    time2 = NVIC_ST_CURRENT_R;
    LCD_OutDec(Data);
    ST7735_OutString(" ");  // spaces cover up characters from last output
    time3 = NVIC_ST_CURRENT_R;
    ADCtime = ((time0-time1)&0x0FFFFFF)/80;	// usec
    OutDectime = ((time2-time3)&0x0FFFFFF)/80; // usec
  }
}


// your function to convert ADC sample to distance (0.01cm)
uint32_t Convert(uint32_t input){
  return 160*input/4096 + 23; // replace this line with your Lab 8 solution
}
int main3(void){

  TExaS_Init();     	// Bus clock is 80 MHz
  ST7735_InitR(INITR_REDTAB);
  ADC_Init();     	// turn on ADC, set channel to 5
  ADC0_SAC_R = 4;   // 16-point averaging, move this line into your ADC_Init()
  while(1){  
    Data = ADC_In();  // sample 12-bit channel 5
    Position = Convert(Data);
    ST7735_SetCursor(0,0);
    LCD_OutDec(Data); ST7735_OutString(" ");
    ST7735_SetCursor(6,0);
    LCD_OutFix(Position); // your Lab 7 solution
  }
}
uint32_t ADCMail;
uint32_t ADCStatus;

void SysTick_Init(void){
	NVIC_ST_CTRL_R = 0;		//disable SysTick to setup timer
	NVIC_ST_RELOAD_R = 8000000 - 1;
	NVIC_ST_CURRENT_R = 0;		//clears current
	NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R & 0x0FFFFFF) | 0x20000000;		//sets priority to 1
	NVIC_ST_CTRL_R = 0x07;		//enables 
}

void SysTick_Handler(void){
	GPIO_PORTF_DATA_R ^= 0x02;		//toggles heartbeat
	Data = ADC_In();
	ADCMail = Data;
	ADCStatus = 1;
}
   
int main(void){
  TExaS_Init();
	PortF_Init();
	ST7735_InitR(INITR_REDTAB);
	ADC_Init();
	ADC0_SAC_R = 4;
	SysTick_Init();
  // your Lab 8
  EnableInterrupts();
  while(1){
		while(ADCStatus == 1){
			Position = Convert(ADCMail);
			ADCStatus = 0;
			ST7735_SetCursor(0,0);
			LCD_OutFix(Position);
			ST7735_OutString(" cm");
		}
  }
}

