//header for basics

#ifndef BASICS_H
#define BASICS_H



//function to shoot lasers
void shootLaser(void);

void Convert(int input);

//function to move player left or right
void PlayerMove(void);

//function to move enemy players straight down
void EnemyMove(void);

void moveLaser(void);

//function to draw all sprites enemies, lasers, player
void drawSprites(void);

//draws start menu where player selects language
void drawStart(void);

//draws pause menu
void drawPause(void);

//removes pause menu
void drawUnpause(void);

//detects collision between laser and enemy
void LaserCollision(void);

//updates the score
void newScore(int currentScore);


int setLanguage(int);

//function to pause the game
void Pause(void);

//function to unpause the game
void unPause(void);

//function to draw ending if loser
void drawEnding(void);

//function to end the game
void endGame(void);

//function to end game if all enemies are killed
void winner(void);

//function to draw winner's screen
void drawWinner(void);

//function to start game
void gameInit(void);

//gets the status of the game whether running or paused
int getStatus(void);

//puts together all the basics of the game
void playGame(void);

void startGame(void);

#endif
