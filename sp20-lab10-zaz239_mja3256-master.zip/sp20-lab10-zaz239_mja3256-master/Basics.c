//this file contains all the basics of the game
//names: Matthew Anderson, Zane Zwanenburg
//i.e. player/enemy movement, laser movement, collisions

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "ADC.h"
#include "Random.h"
#include "ST7735.h"
#include "Sound.h"
#include "Images.h"
#include "Print.h"
#include "shootButton.h"


uint8_t enemiesKilled = 0;	
uint8_t score = 0;					//updates score
uint8_t ending = 0;					//flag to end game
uint8_t gameStatus = 0;		//flag to notify game is running 0=start/end, 1=running, 2=paused
int langFlag;					//flag to choose language 1 = english, 0 = Spanish

uint32_t Convert(uint32_t input);

struct LaserSprite{
	int xPos;											//x position
	int yPos;											//y position
	int live;											//status of laser (alive/dead)
	const unsigned short *image; 	//pointer to bitmaps
	int speed;										//speed of laser
};
typedef struct LaserSprite Laser_t;		//laser sprite datatype
Laser_t Shoot;

struct PlayerSprite{
	int xPos;											//x position of player
	int yPos;											//y position of player (should not change)
	int live;											//life status of player (either live or dead)
	const unsigned short *image;
};
typedef struct PlayerSprite Player_t;		//Player_t sprite datatype
Player_t Player;											//set max players to 1

struct EnemySprite{
	int xPos;													//x position of enemy (should not change)
	int yPos;													//y position of enemy
	int live;													//life status of enemy (either live or dead)
	const unsigned short *image;
};
typedef struct EnemySprite Enemy_t;
Enemy_t Enemy[10];								//sets max enemies to 10

void endGame(void);
void startGame(void);
void winner(void);
int setLanguage(int input);

// your function to convert ADC sample to distance (0.01cm)
uint32_t Convert(uint32_t input){
  return 160*input/4096 + 23; // replace this line with your Lab 8 solution
}

//player only moves in the x direction
void PlayerMove(void){
	uint32_t ADCMail;
	ADCMail = ADC_In();
	ST7735_DrawBitmap(Player.xPos, Player.yPos, replacePlayer, 18, 8);
	Player.xPos = Convert(ADCMail)-18;
	if((Player.xPos <= 110) && (gameStatus == 1)){
		Player.xPos = Convert(ADCMail)-18;
	}
	if((Player.xPos > 110) && (gameStatus == 1)){
		Player.xPos = 110;
	}
}


//enemy only moves in the y direction
void EnemyMove(void){
	for(int i = 0; i<10; i++){
		Enemy[i].yPos +=1;					//move down
		if((Enemy[i].yPos > Player.yPos + 8) && (gameStatus == 1)){
			endGame();
		}
	}
}

void shootLaser(void){
	Shoot.xPos = Player.xPos + 9;										//sets laser in the middle of player's ship
	Shoot.yPos = Player.yPos - 8;										//sets laser at the front of the ship
	Shoot.image = Laser;
	Shoot.speed = 1;
	Shoot.live = 1;																	//Laser is alive and moving
}


void moveLaser(void){
	if(Shoot.live == 1){
		if(Shoot.yPos > 30){
			Shoot.yPos = Shoot.yPos - Shoot.speed;
		}
		else{
			Shoot.live = 0;
			ST7735_DrawBitmap(Shoot.xPos, Shoot.yPos, replaceLaser, 2, 10);
		}
	}
}

void drawSprites(void){
	//draw player ship
	if(Player.live == 1){																												//draws alive player ship
		ST7735_DrawBitmap(Player.xPos, Player.yPos, PlayerShip0, 18, 8);
	}
	else{																																				//drawSprites blank space for dead player
		ST7735_DrawBitmap(Player.xPos, Player.yPos, replacePlayer, 18, 8);
	}
	
	//draw enemies
	for(int i = 0; i<5; i++){
		if(Enemy[i].live == 1){																										// draws alive enemy
			ST7735_DrawBitmap(Enemy[i].xPos, Enemy[i].yPos, SmallEnemy10pointA, 16, 10);
		}
		else{																																			//drawSprites blank space for dead enemy
			ST7735_DrawBitmap(Enemy[i].xPos, Enemy[i].yPos, replaceEnemy, 16, 10);
		}
	}
	for(int i = 5; i<10; i++){
		if(Enemy[i].live == 1){																										// draws alive enemy
			ST7735_DrawBitmap(Enemy[i].xPos, Enemy[i].yPos, SmallEnemy30pointA, 16, 10);
		}
		else{																																			//drawSprites blank space for dead enemy
			ST7735_DrawBitmap(Enemy[i].xPos, Enemy[i].yPos, replaceEnemy, 16, 10);
		}
	}
	
	//draw laser
	if(Shoot.live == 1){
		ST7735_DrawBitmap(Shoot.xPos, Shoot.yPos, Laser, 2, 10);
		Sound_Shoot();
	}
}

//function to draw Start screen
void drawStart(void){
	ST7735_FillScreen(0x0000);
	ST7735_SetCursor(5,1);
	ST7735_OutString("Start Game");
	ST7735_SetCursor(1, 3);
	ST7735_OutString("B0 is Onboard");
	ST7735_SetCursor(1, 4);
	ST7735_OutString("B1 is External");
	ST7735_SetCursor(1, 6);
	ST7735_OutString("B0 para Espa\xA4ol");
	ST7735_SetCursor(1, 7);
	ST7735_OutString("B1 for English");
}
//draw pause menu
//still need to add factor for language change
void drawPause(void){
	if(langFlag == 1){
		ST7735_SetCursor(5,7);
		ST7735_OutString("Game Paused");
	}
	if(langFlag == 0){
		ST7735_SetCursor(3,7);
		ST7735_OutString("Juego en Pausa");
	}
}

void drawUnpause(void){
	if(langFlag == 1){
		ST7735_SetCursor(5,7);
		ST7735_OutString("           ");
	}
	if(langFlag == 0){
		ST7735_SetCursor(3,7);
		ST7735_OutString("              ");
	}
}

//function to update score
void newScore(int currentScore){
	if(langFlag == 1){
		ST7735_SetCursor(7, 1);
		ST7735_OutString("Score: ");
		LCD_OutDec(currentScore);
	}
	if(langFlag == 0){
		ST7735_SetCursor(3, 1);
		ST7735_OutString("el marcador: ");
		LCD_OutDec(currentScore);
	}
}


//function to determine if laser hits enemy
void LaserCollision(void){
	for(int i=0; i<10; i++){
		if(Enemy[i].live == 1){
			if((Enemy[i].xPos <= Shoot.xPos) && (Shoot.xPos <= Enemy[i].xPos+16) && (Enemy[i].yPos <= Shoot.yPos) && (Shoot.yPos <= Enemy[i].yPos+10)){
				Enemy[i].live = 0;
				Shoot.live = 0;
				Sound_Explosion();
				score++;
				newScore(score);
				enemiesKilled++;
			}
		}
	}
	if(enemiesKilled == 10){
		Sound_Highpitch();
		winner();
	}
}


//sets the language flag to determine language
int setLanguage(int input){
	langFlag = input;
	return langFlag;
}


//function to pause the game
//still testing
void Pause(void){
	gameStatus = 2;
	TIMER1_CTL_R = 0x00;
	drawPause();
}

//unpauses the game
void unPause(void){
	gameStatus = 1;
	TIMER1_CTL_R = 0x01;
	drawUnpause();
}

//ending for losers
void drawEnding(void){
	if(langFlag == 1){
			ST7735_FillScreen(0x0000);            // set screen to black
			ST7735_SetCursor(7, 1);
			ST7735_OutString("Game Over");
			ST7735_SetCursor(7, 2);
			ST7735_OutString("Try Again");
			ST7735_SetCursor(7, 3);
			ST7735_OutString("Score: ");
			LCD_OutDec(score);
	}
	else{
			ST7735_FillScreen(0x0000);            // set screen to black
			ST7735_SetCursor(5, 1);
			ST7735_OutString("Fin del Juego");
			ST7735_SetCursor(3, 2);
			ST7735_OutString("Vuelve a Intentar");
			ST7735_SetCursor(4, 3);
			ST7735_OutString("el marcador: ");
			LCD_OutDec(score);
		}
}
//function to draw endgame screen based off win or loss
void endGame(void){
	drawEnding();   // draw game over screen
	gameStatus = 0;
	while(1){								// infinite loop
	}
}

//function to draw winner screen
void drawWinner(void){
			if(langFlag == 1){
			ST7735_FillScreen(0x0000);            // set screen to black
			ST7735_SetCursor(7, 1);
			ST7735_OutString("Congrats!");
			ST7735_SetCursor(7, 2);
			ST7735_OutString("You Win");
			ST7735_SetCursor(7, 3);
			ST7735_OutString("Score: ");
			LCD_OutDec(score);
		}
		else{
			ST7735_FillScreen(0x0000);            // set screen to black
			ST7735_SetCursor(5, 1);
			ST7735_OutString("Felicidades");
			ST7735_SetCursor(5, 2);
			ST7735_OutString("Usted Gana");
			ST7735_SetCursor(5, 3);
			ST7735_OutString("el marcador: ");
			LCD_OutDec(score);
		}
	}

//function to end game if all enemies are killed
void winner(void){
	if(enemiesKilled == 10){		// check number of alive enemies
		gameStatus = 0;
		drawWinner();
		while(1){}
	}
}
//function to initialize the game
void gameInit(void){
	uint8_t i = 0;
	gameStatus = 1;
	enemiesKilled = 0;
	score = 0;
	
//starting position, image, and life for player	
	Player.xPos = 56;
	Player.yPos = 159;
	Player.image = PlayerShip0;
	Player.live = 1;
	
//starting position for enemies
	for(i=0;i<5;i++){
		Enemy[i].xPos = (16*i)+20;
		Enemy[i].yPos = 30;
		Enemy[i].image = SmallEnemy10pointA;
		Enemy[i].live = 1;
	}
	int k = 0;
	for(i=5;i<10;i++){
		Enemy[i].xPos = (16*k)+20;
		Enemy[i].yPos = 50;
		Enemy[i].image = SmallEnemy20pointA;
		Enemy[i].live = 1;
		k++;
	}
	newScore(score);
	drawSprites();
}
//gets the game status
int getStatus(void){
	return gameStatus;
}
void startGame(void){
	if(gameStatus == 0){
		gameStatus = 1;
	}
}

//function that puts the basics of the game together
void playGame(void){
	if(gameStatus == 1){
		PlayerMove();
		moveLaser();
		LaserCollision();
		drawSprites();
		winner();
	}
}
