//initialization of buttons
//names:Matthew Anderson, Zane Zwanenburg
//PE1 is shoot button with edge trigger interrupts
//PF4 is start and stop button

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "Basics.h"

volatile uint32_t FallingEdges = 0;
uint8_t isPressed = 0;
uint8_t isPressed1 = 0;
uint8_t isPressed2 = 0;
uint8_t langFlag1;
uint8_t gameStatus1;

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts


// Initalizes PF4 to trigger interrupt upon falling edge
void EdgeCounter_Init(void){       
  uint32_t volatile delay;
  SYSCTL_RCGCGPIO_R |= 0x00000020; // (a) activate clock for port F
  delay = SYSCTL_RCGCGPIO_R
  GPIO_PORTF_DIR_R &= ~0x10;    // (c) make PF4,0 in (built-in button)
  GPIO_PORTF_DEN_R |= 0x10;     //     enable digital I/O on PF4,0
  GPIO_PORTF_PUR_R |= 0x10;     //     enable weak pull-up on PF4,0
  GPIO_PORTF_IS_R &= ~0x10;     // (d) PF4 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x10;    //     PF4 is not both edges
  GPIO_PORTF_IEV_R &= ~0x10;    //     PF4 falling edge event
  GPIO_PORTF_ICR_R = 0x10;      // (e) clear flag4
  GPIO_PORTF_IM_R |= 0x10;      // (f) arm interrupt on PF4
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x40000000;      // (h) enable interrupt 30 in NVIC
  EnableInterrupts();           // (i) Enable global Interrupt flag (I)
}

void GPIOPortF_Handler(void){
	if(GPIO_PORTF_RIS_R == 0x10){		//if PF4 is triggered
		GPIO_PORTF_ICR_R = 0x10;      // acknowledge flag4
		isPressed1 ^= 1;
		gameStatus1 = getStatus();
		if(gameStatus1 == 0){
			setLanguage(0);
			startGame();
		}
		if(gameStatus1 == 1){
			Pause();
		}
		if(gameStatus1 == 2){
			unPause();
		}
	}
}





void EdgeTriggeredA_Init(void){
  uint32_t volatile delay;
  SYSCTL_RCGCGPIO_R |= 0x00000010; // (a) activate clock for port E
  delay = SYSCTL_RCGCGPIO_R;       // (b) initialize count and wait for clock
  GPIO_PORTE_DIR_R &= ~(0x02);    // (c) make PE1 in (built-in button)
  GPIO_PORTE_DEN_R |= 0x02;     //     enable digital I/O on PE1
  GPIO_PORTE_IS_R &= ~0x02;     // (d) PF4 is edge-sensitive
  GPIO_PORTE_IBE_R &= ~0x02;    //     PF4 is not both edges
  GPIO_PORTE_IEV_R &= ~0x02;    //     PF4 falling edge event
  GPIO_PORTE_ICR_R = 0x02;      // (e) clear flag1
  GPIO_PORTE_IM_R |= 0x02;      // (f) arm interrupt on PE1
  NVIC_PRI1_R = (NVIC_PRI1_R&0xFFFFFF1F)|0x000000A0; // (g) priority 5
  NVIC_EN0_R = 0x10;      // (h) enable interrupt 4 in NVIC
	EnableInterrupts();
}

void GPIOPortE_Handler(void){
	GPIO_PORTE_ICR_R = 0x02;      // acknowledge flag1
	isPressed2 ^= 0x02;
	gameStatus1 = getStatus();
	if(gameStatus1 == 1){
		shootLaser();
	}
	if(gameStatus1 == 0){
		setLanguage(1);
		startGame();
	}
}




