#ifndef SHOOTBUTTON_H
#define SHOOTBUTTON_H


// Initalizes PF4 to trigger interrupt upon falling edge
void EdgeCounter_Init(void);

//PortF Handler
void GPIOPortF_Handler(void);

// Initalizes PE1 to trigger interrupt upon falling edge
void EdgeTriggeredA_Init(void);

//PortE Handler
void GPIOPortE_Handler(void);
#endif
