// Lab6.c
// Runs on LM4F120 or TM4C123
// Use SysTick interrupts to implement a 4-key digital piano
// MOOC lab 13 or EE319K lab6 starter
// Program written by: Matthew Anderson Zane Zwanenburg
// Date Created: 3/6/17 
// Last Modified: 1/17/2020 
// Lab number: 6
// Hardware connections
// TM4C123


#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "Sound.h"
#include "Piano.h"
#include "TExaS.h"
#include "dac.h"

// basic functions defined at end of startup.s
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "Sound.h"
#include "Piano.h"
#include "TExaS.h"

//basic functions defined at end of startup.s
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
void Delay1ms(int time);  	// blind wait
void LaunchPad_Init(void);
uint32_t Switch_In(void);
void DAC_Init(void);     	// your lab 6 solution
void DAC_Out(uint8_t data);  // your lab 6 solution
uint8_t Testdata;

//// lab video Lab6_voltmeter
//int main(void){ //voltmetermain(void){	 
//  TExaS_Init(SW_PIN_PE3210,DAC_PIN_PB3210,ScopeOn);	// bus clock at 80 MHz
//  DAC_Init(); // your lab 6 solution
//  Testdata = 15;
//  EnableInterrupts();
//  while(1){           	 
//    Testdata = (Testdata+1)&0x0F;
//    DAC_Out(Testdata);  // your lab 6 solution
//  }
//}




// //lab video Lab6_static
//int main(void){   uint32_t last,now;  
//  TExaS_Init(SW_PIN_PE3210,DAC_PIN_PB3210,ScopeOn);	// bus clock at 80 MHz
//  LaunchPad_Init();
//  DAC_Init(); // your lab 6 solution
//  Testdata = 15;
//  EnableInterrupts();
//  last = Switch_In();
//  while(1){           	 
//    now = Switch_In();
//    if((last != now)&&now){
//      Testdata = (Testdata+1)&0x0F;
//      DAC_Out(Testdata); // your lab 6 solution
//    }
//    last = now;
//    Delay1ms(25);   // debounces switch
//  }
//}

//__asm void
//Delay(void){    
// 	and r0,r0  // 12.5ns each
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	and r0,r0
// 	bx  R14
//}
//// very very approximate delay
//void Delay1ms(int time){ int i;
//  for(;time;time--){
//    for(i=0;i<1200;i++) Delay();
//  }
//}

////---------------------LaunchPad_Init---------------------
//// initialize switch interface
//// Input: none
//// Output: none
//void LaunchPad_Init(void){ volatile uint32_t delay;
//  SYSCTL_RCGCGPIO_R |= 0x00000020; 	// activate clock for Port F;
//  delay = 100; delay=100; delay=100;
//  GPIO_PORTF_LOCK_R = 0x4C4F434B;   // unlock GPIO Port F
//  GPIO_PORTF_CR_R = 0x1F;       	// allow changes to PF4-0
//  // only PF0 needs to be unlocked, other bits can't be locked
//  GPIO_PORTF_DIR_R = 0x0E;      	// PF4,PF0 in, PF3-1 out
//  GPIO_PORTF_PUR_R = 0x11;      	// enable pull-up on PF0 and PF4
//  GPIO_PORTF_DEN_R = 0x1F;      	// enable digital I/O on PF4-0
//}

////---------------------Switch_In---------------------
//// read the values of the two switches
//// Input: none
//// Output: 0x00,0x01,0x10,0x11 from the two switches
////     	0 if no switch is pressed
//// bit4 PF4 SW1 switch
//// bit0 PF0 SW2 switch
//uint32_t Switch_In(void){
//  return (GPIO_PORTF_DATA_R&0x11)^0x11;
//}
//int main(void){     
//  TExaS_Init(SW_PIN_PE3210,DAC_PIN_PB3210,ScopeOn);    // bus clock at 80 MHz
//  Piano_Init();
//  Sound_Init();
//	DAC_Init();
//	uint32_t data;
//	for(;;) {
//    DAC_Out(data);
//    data = 0x0F & (data+1);
//	}
//}
void HB_Init(void){
	uint32_t wait = 1000000;
	SYSCTL_RCGCGPIO_R |= 0x20;
	while(wait){
		wait--;
	}
	GPIO_PORTF_DIR_R |= 0x04;
	GPIO_PORTF_DEN_R |= 0x04;	
}
void HB_loop(void){
	uint32_t wait = 1000000;
	GPIO_PORTF_DATA_R ^= 0x04;
	while(wait){
		wait--;
	}
}


int main(void){     
  TExaS_Init(SW_PIN_PE3210,DAC_PIN_PB3210,ScopeOn);    // bus clock at 80 MHz
  Piano_Init();
  Sound_Init();
  // other initialization
	HB_Init();
  EnableInterrupts();
  while(1){
		if(Piano_In() != 0){
			HB_loop();
			uint32_t PianoKey = Piano_In();
			if(PianoKey == 0x01){
				Sound_Play(F);
			}
			else if(PianoKey == 0x02){
				Sound_Play(G);
			}
			else if(PianoKey == 0x04){
				Sound_Play(A);
			}
			else if(PianoKey == 0x08){
				Sound_Play(C1);
			}
		}
		else{
			Sound_Play(0);
		}
	}    
}
//int main(void){ uint32_t data; // 0 to 15 DAC output
//  TExaS_Init(SW_PIN_PE3210,DAC_PIN_PB3210,ScopeOn);
//  DAC_Init();
//    uint32_t volatile delay;
//  SYSCTL_RCGCGPIO_R |= 0x20; // activate port F
//  delay = SYSCTL_RCGCGPIO_R;    // allow time to finish PortB clock activating
//  GPIO_PORTF_DIR_R |= 0x08;      // make PF3 out
//  GPIO_PORTF_DEN_R |= 0x08;      // enable digital I/O on PF3
//  for(;;) {
//        //for(int i=0; i<5000000; i++){
//    DAC_Out(5);
//        //}
//        GPIO_PORTF_DATA_R ^= 0x08;//toggle PF3,onboard led, as heartbeat
//    data = 0x0F&(data+1); // 0,1,2...,14,15,0,1,2,...

//    }
//}


